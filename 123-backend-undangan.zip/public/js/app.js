document.addEventListener('DOMContentLoaded', () => {
    const INFO = document.getElementById('information');
    INFO.innerText = 'for educational purposes || ready for production';
});