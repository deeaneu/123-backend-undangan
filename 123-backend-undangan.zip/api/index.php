<?php

/**
 * Redirect request to public
 * 
 * Vercel + PHP
 */

require_once __DIR__ . '/../public/index.php';
